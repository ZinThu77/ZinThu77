
<?php  
 defined('BASEPATH') OR exit('No direct script access allowed');  
 

 class fdashboard extends CI_Controller 
 {  
      //functions  
    public function index()
    {  
           $this->load->model("fdashboard_model");  
           $data["fetch_data"] = $this->fdashboard_model->fetch_data();  
            
           $this->load->view("fdashboard_view", $data);  
    }
    public function form_validation()
    {
    	$this->load->library('form_validation');
    	$this->form_validation->set_rules("bname","B Name",'required');
    	$this->form_validation->set_rules("category","Category",'required');
    	$this->form_validation->set_rules("price","Price",'required');
    	if($this->form_validation->run())
    	{
    		$product_image='';
    		$this->load->model("fdashboard_model");
    		if($_POST["product_image"]["name"]!='')
    		{
    			$product_image = $this->input->post("product_image");
    		}
    		else
    		{
    			$product_image = $this->input->post("product_old_image");
    		}
    		echo 'Test Outside=';
    		echo $product_image;
    		$data =  array(
    			"bname" => $this->input->post("bname"),
    		    "category" => $this->input->post("category"),
    		    "price" => $this->input->post("price"),
    		    "img" => $product_image);
    		echo $data;
    		if($this->input->post("update"))
    		{
    			$this->fdashboard_model->update_data($data,$this->input->post("hidden_id"));
    			redirect(base_url()."fdashboard/updated");
    		}
    		if($this->input->post("insert"))
    		{
    			$this->fdashboard_model->insert_data($data);
    			redirect(base_url()."fdashboard/inserted");
    		}
    	}
    	else
    	{
    		$this->index();
    	}
    }  

    public function inserted()  
    {  
        $this->index();  
    }  

   public function update_data(){  
           $user_id = $this->uri->segment(3);  
           $this->load->model("fdashboard_model");  
           $data["user_data"] = $this->fdashboard_model->fetch_single_data($user_id);  
           $data["fetch_data"] = $this->fdashboard_model->fetch_data();  
           $this->load->view("fdashboard_view", $data);  
           $this->load->view("fdashboard_view", $data);  
      } 


           public function updated()  
      {  
           $this->index();  
      }
      public function delete_data(){  
           $id = $this->uri->segment(3);  
           $this->load->model("fdashboard_model");  
           $this->fdashboard_model->delete_data($id);  
           redirect(base_url() . "fdashboard/deleted");  
      } 

                 public function deleted()  
      {  
           $this->index();  
      }

}
?>

