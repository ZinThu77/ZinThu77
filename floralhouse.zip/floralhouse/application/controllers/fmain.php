<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class fmain extends CI_Controller {

	public function index()
	{
		$this->load->view("fmain");
	}
	public function login_validation()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
		if($this->form_validation->run())
		{
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$this->load->model('fmain_model');
			if($this->fmain_model->check_login($username,$password))
			{
				$session_data=array('username'=>$username);
				$this->session->set_userdata($session_data);
				redirect(base_url().'fmain/enterdashboard');
			}
			else
			{
              $this->session->set_flashdata('error','Invalid username and password');
              redirect(base_url().'fmain/login');
			}
			
		} 
		else
			{
				$this->index();
			}
	}
	public function form_validation()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules("name","Name","required");
		$this->form_validation->set_rules("address","Address","required");
		if($this->form_validation->run())
		{
			$this->load->model("fmain_model");
		}
		else
		{
			$this->index();
		}
	}
	public function enterdashboard()
	{
		if($this->session->userdata('username')!='')
		{
			redirect(base_url().'fdashboard/index');

		}
		else
		{
			redirect(base_url().'fmain/login');
		}
	}
	public function login()
	{
		$this->load->view("fmain");
	}
	function logout()
	{
		$this->session->unset_userdata('username');
		redirect(base_url().'fmain/login');
	}
	
}
