<?php
class fdashboard_model extends CI_Model
{
	function fetch_data()
	{
		$this->db->order_by("id","DESC");
		$this->db->select("*");
		$this->db->from("bouquet_list");
		$query = $this->db->get();
		return $query;
	}
	function insert_data($data)
	{
		$this->db->insert("bouquet_list",$data);
	}
	function update_data($data,$id)
	{
		$this->db->where("id",$id);
		$this->db->update("bouquet_list",$data);
	}
	function fetch_single_data($id)
      {
      	$this->db->where("id",$id);
      	$query = $this->db->get("bouquet_list");
      	return $query;
      }
      function delete_data($id)
      {
      	$this->db->where("id",$id);
      	$this->db->delete("bouquet_list");
      }
}
?>
