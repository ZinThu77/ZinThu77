<?php

class fmain_model extends CI_Model
{
	function check_login($username,$password)
	{
		$this->db->where('username',$username);
		$this->db->where('password',$password);
		$query=$this->db->get("login");
		if($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
?>