<!DOCTYPE html>
 <html>
 <head>
   <title>Floral House Admin Dashboard </title>  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> 

     <!--for class="delete_data"-->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>


 </head>
 <body>
 	 <div class="container"> 
	 	<h1>Admin Dashboard</h1>

	 	<label><a href="'.base_url().'fmain/logout">Logout</a></label>
	 </div>


	 <div class="container" style="width: 50%;text-align: left">
	 	<div class="row">
     <h1 align="center">Insert Update Delete Data using Codeigniter</h1><br />  
      <form method="post" action="<?php echo base_url()?>fdashboard/form_validation">  
           <?php  
           if($this->uri->segment(2) == "inserted")  
           {  
   
                echo '<p class="text-success">Data Inserted</p>';  

           }  
           if($this->uri->segment(2) == "updated")  
           {  
                echo '<p class="text-success">Data Updated</p>';  
          }  
           ?>

          <?php  
           if(isset($user_data))  
           {  
                foreach($user_data->result() as $row)  
                {  
           ?>  

           <div class="form-group">  
                <label>Enter Bouquet Name</label>  
                <input type="text" name="bname" value="<?php echo $row->bname; ?>" class="form-control" />  
                <span class="text-danger"><?php echo form_error("bname"); ?></span>  
           </div> 
            <div class="form-group">  
                <label>Enter Category</label>  
                <input type="text" name="category" value="<?php echo $row->category; ?>" class="form-control" />  
                <span class="text-danger"><?php echo form_error("category"); ?></span>  
           </div>
           <div class="form-group">  
                <label>Enter Price</label>  
                <input type="text" name="price" value="<?php echo $row->price; ?>" class="form-control" />  
                <span class="text-danger"><?php echo form_error("price"); ?></span>  
           </div> 

           <div class="form-group">  
                <label>Select Product Image</label>

                <?php echo '<img src="'.base_url().'images/'.$row->img.'" class="img-thumnail" width="50" height="35"/>'; ?>
                
                <input type="file" name="product_image" id="product_image"> 
                <input type="hidden" name="product_old_image" id="product_old_image" value="<?php echo $row->img; ?>">    

           </div>   
           <div class="form-group">  
                <input type="hidden" name="hidden_id" value="<?php echo $row->id; ?>" />  
                <input type="submit" name="update" value="Update" class="btn btn-info" />  
           </div>       
           <?php       
                }  
           }  
           else  
           {  
           ?>  

           <div class="form-group">  
                <label>Enter Bouquet Name</label>  
                <input type="text" name="bname" class="form-control" />  
                <span class="text-danger"><?php echo form_error("bname"); ?></span>  
           </div>
             <div class="form-group">  
                <label>Enter Category</label>  
                <input type="text" name="category" class="form-control" />  
                <span class="text-danger"><?php echo form_error("category"); ?></span>  
           </div>
           <div class="form-group">  
                <label>Enter Price</label>  
                <input type="text" name="price" class="form-control" />  
                <span class="text-danger"><?php echo form_error("price"); ?></span>  
           </div>  
           <div class="form-group">
                <label>Upload Image</label>       
                <input type="file" name="product_image" id="product_image">
                <span id="product_uploaded_image"></span>
           </div>
           <div class="form-group">  
                <input type="submit" name="insert" value="Insert" class="btn btn-info" />  
           </div>       
          <?php  
           }  
           ?>  
      </form>
<br><br>

	 		
	 	</div>
	 	
	 </div>





	 <div class="container">
	 	<div class="row">



	 		<div class="col-md-12 col-sm-12">
	 			     <h3>Fetch Data from Table using Codeigniter</h3><br />  
      <div class="table-responsive">  
           <table class="table table-bordered">  
                <tr>  
                     <th>ID</th>  
                     <th>Bouquet Name</th>
                     <th>Category</th>
                     <th>Price</th>  
                     <th>Image</th>  
                     <th>Delete</th>  
                     <th>Update</th>  
                </tr>  
           <?php  
           if($fetch_data->num_rows() > 0)  
           {  
                foreach($fetch_data->result() as $row)  
                {  
           ?>  
                <tr>  
                     <td><?php echo $row->id; ?></td>  
                     <td><?php echo $row->bname; ?></td> 
                     <td><?php echo $row->category; ?></td> 
                     <td><?php echo $row->price; ?></td>                     
                     
                     <td><?php echo '<img src="'.base_url().'images/'.$row->img.'" class="img-thumnail" width="50" height="35"/>'; ?></td>  
 
                     <td><a href="#" class="delete_data" id="<?php echo $row->id; ?>" >Delete</a></td>  
                     <td><a href="<?php echo base_url(); ?>fdashboard/update_data/<?php echo $row->id; ?>">Edit</a></td>  
                </tr>  
           <?php       
                }  
           }  
           else  
           {  
           ?>  
                <tr>  
                     <td colspan="5">No Data Found</td>  
                </tr>  
           <?php  
           }  
           ?>  
           </table>  
      </div>  

	 			
	 		</div>

	 	</div>
	 	
	 </div>


   <script>  
      $(document).ready(function(){  
           $('.delete_data').click(function(){  
                var id = $(this).attr("id");  
                if(confirm("Are you sure you want to delete this?"))  
                {  
                     window.location="<?php echo base_url(); ?>fdashboard/delete_data/"+id;  
                }  
                else  
                {  
                     return false;  
                }  
           });  
      });  
      </script>  


 </body>
</html> 

