<!DOCTYPE html>
<html>
<head>
	<title>Floral House</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<!--For Responsive Design-->
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script type="text/javascript" src="https://ff.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=PnbmNQ4TFFd_of0fuTp48CzKDSjB4Jk2aY9xfJYLNrsq4zEkBBezcjevD2PwbVThJavdgYIt3CgbPPLAENhV0YUchIC50kMUV8nOZP1q9856YJfsh15BlGpNvpK63Vui-9jt6A1vY1Jdi87wBICQN8AfKqbAhVIXIBPB0nXgSM8G9Bp0kXPRvyT3P569HcDYJOqLrCqHmtk2SXL8P02LiK6ME7P6mhSlzsZK_4_q-PaT2PgcTILAwEDTRQdOcLWatexNklXgnLZyvDkYPkKC1UHJQUdMuXkjRaWxPjpYCK5B4n4BxMgAkFtG5FfSZZVcWU-A9FN7h2FSTLCSXO_sIaj6Y7qFskfaN4x_4-2_ysI6uTvPrGLm64vMdUq1gWhPsO-WSMp8FK7vJBLMLStGGpqnFhWVdfY9BR7UTmj1APreUKezwGjh1e8Ak4A_NpUoDihHwCplkw0Bb102tqoO6OtNX3UQPYpcCOQgcHB3Pq9LU3UGE_uqg4cDRI2Lzs1XxGEQlSfm5BXDTAdJzdcvHBt64zShfltgcYMDIlZIuqaQvm_38q7HMUxY-bga9X93hNsjmRcNABTxdxnG0r_Jq2oK0xkCRhl8wLC9lHCRRN0Te75w-tM4f6_NM3EMIC8Odzq58VpFWEGyEE3a0WOfMXh6gjFyZ5_MtJMy5zsrBWWQPLPJ7Zap3IPe9Ht2TZ9nvfVtir-N-ldvB1h6W74HQoD2Hn1pe9COuKeE9DKwPLPuYQ9drBk9X-YMSZLRbQViRUDxsZqewxuCHYy31L6o2DL3RVdIF9ZeeMvPsBh3awcSinupupkGe_uvf1QetkcbB4ihncH0n6PXSZzznmXu5BFX8HVUNjT3z919twZCWDgrFvrK5MUPkx-GHZxYoEIjhWr1DiCQZ3kzelZVe_b64HRtIx221NbBvVrS6XxykwhoQlje-QJ4kLki51Q9g0N_HSKzg-3Hp50nuZOr1QA0CJgLG7S-jLjbdLT-hL6bK2phdV4nfRrqycoNFKNpxQo58kCxv1MIy209jYAH4Ur7ZTSQXBbcXbEHnQ2zTaM4w3wTaMxfJudVtyMOSradyLl9KidWS55Uw_NkUnatKfMUT0oUnJfoxlMXKaiy-UdhIqm81mjdc5DShlNvFq30DIeDUn_r1P8eKmpqDAnljoeDAPTfL5rIm5OUU3WnWuLF-YNRb15TVx8dlEmnT1dzVGC8AM-eEJxAi8UnJHjRGyNQ3A" nonce="991e8ba2a48e853e90c53dc3e7a35e9d" charset="UTF-8"></script><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<!--For glyph icon-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

	<h1 style="color: purple">Floral House</h1>
	<nav class="navbar navbar-expand-lg navbar-info bg-info">
		<div class="container-fluid">
			
			<ul class="nav navbar-nav">
				<li class="active"><a href="fmain">Home</a></li>
				<li><a href="#birthday">Birthday</a></li>
				<li><a href="#anniversary">Anniversary</a></li>
				<li><a href="#flowers">Flowers</a></li>
				<li><a href="#plants">Plants</a></li>
				<li><a href="#aboutus">About Us</a></li>
				<li><a href="#contactus">Contact Us</a></li>
			</ul>
		</div>
	</nav>
	<div class="container-fluid">
	<div class="row">
	<img src="images/home.jpg" class="img-responsive">
	</div>
</div>
	<div id="birthday">
	<div class="container-fluid">
		<h1 style="color: purple">Birthday Bouquet</h1>
		<div class="row">
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/b1.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Smile & Sunshine</h4>
				<p style="text-align:center;">20000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/b2.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Light of My Life</h4>
				<p style="text-align:center;">20000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/b3.png" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Raspberry Rush</h4>
				<p style="text-align:center;">18000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
		</div>
	</div>
	<div id="anniversary">
	<div class="container-fluid">
		<h1 style="color: purple">Anniversary Bouquet</h1>
		<div class="row">
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/a1.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">You're Presious</h4>
				<p style="text-align:center;">25000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/a2.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Classic Ivory</h4>
				<p style="text-align:center;">25000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/a3.png" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Ture Love</h4>
				<p style="text-align:center;">30000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
		</div>
	</div>
	<div id="flowers">
	<div class="container-fluid">
		<h1 style="color: purple">Flowers</h1>
		<div class="row">
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/f1.png" class="img-responsive">
				</div>
				<h4 style="text-align:center;">100 Roses</h4>
				<p style="text-align:center;">20000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/f2.png" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Wild Flowers</h4>
				<p style="text-align:center;">20000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/f3.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Lavendar Bundles</h4>
				<p style="text-align:center;">35000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
		</div>
	</div>
	<div id="plants">
	<div class="container-fluid">
		<h1 style="color: purple">Plants</h1>
		<div class="row">
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/p1.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">20 Succulents</h4>
				<p style="text-align:center;">40000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/p2.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Lucky Bamboo Plant</h4>
				<p style="text-align:center;">10000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/p3.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Anthurium</h4>
				<p style="text-align:center;">10000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
		</div>
	</div>
	<div id="aboutus">
        <div class="container-fluid">
        	<h1 style="color:purple;">About Us</h1>
        	<div class="row">
        		<div class="col-sm-12 col-md-4">
        			<h2>Owner</h2>
        			<p>Ms. Zin Thu</p>
        			<div style="width:200px; height: 200px">
        				<img src="images/owner.png" class="img-circle">
        			</div>
        		</div>
        		<div class="col-sm-12 col-md-4">
        			<h2>Florist</h2>
        			<p>Ms. Jenny</p>
        			<div style="width: 300px; height: 300px">
        				<img src="images/florist.png" class="img-circle">
        			</div>
        		</div>
                <div class="col-sm-12 col-md-4" style="background-color: white;">
                	<form action="<?php echo base_url();?>fmain/login_validation" method="post">
                		<legend>Login</legend>
                		<div class="form-group">
                			<label>Username:</label>
                			<input type="text" name="username" class="form-control" required="required" placeholder="Enter Username" autocomplete="off" autofocus="autofocus">
                			<span class="text-danger"><?php echo form_error('username');?></span>
                		</div>
                		<div class="form-group">
                			<label>Password:</label>
                			<input type="Password" name="password" class="form-control" required="required" placeholder="Enter Your Password" autocomplete="off" autofocus="autofocus">
                			<span class="text-danger"><?php echo form_error('password');?></span>
                		</div>
                		<div class="form-group">
                			<input type="submit" name="insert" value="Login" class="btn btn-info">
                		</div>
                	</form>

                </div>
        	</div>
        </div>
    </div>

	</div>
	<div id="contactus">
    <div class="container-fluid">
    	<h1 style="color: purple">Contact Us</h1>
    	<div class="row">
    		<div class="col-md-6 col-sm-12">
    			<h2>Shop Address</h2>
    			<p>Address: No.(155),<sup>nd</sup>Hnin Ni Street, Thuwana Township, Yangon, Myanmar</p>
    			<p>Phone: +95 9253462288, 9797609166</p>
    			<p>Email: floralhouse@gmail.com</p>
    		</div>
    		<div class="col-md-6 col-sm-12">
    			<img src="images/shop.jpg" class="img-responsive">
    		</div>
    	</div>
	</div>
</div>
<div class="col-md-6 col-sm-12">
	<h1>Floral House</h1>
	<h2>Location Map</h2>
		<div style="width: 100%"><iframe scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=Hnin%20Si%20Ni%20Street,%20thuwana%20ward,%20yangon,%20myanmar+(Floral%20House)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" width="100%" height="600" frameborder="0"></iframe><a href="https://www.mapsdirections.info/en/measure-map-radius/">Radius distance map</a></div>
	</div>
	<div class="col-md-6 col-sm-12">
		<h1>See Your location</h1>
		<button onclick="getLocation()">Check my location</button>
		<p id="demo"></p>
		<script>
var x = document.getElementById("demo");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
    p=x.innerHTML;
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude + 
  "<br>Longitude: " + position.coords.longitude;
}
</script>
		</script>
		<div style="width: 100%"><iframe scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=500&amp;hl=en&amp;q=p&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" width="100%" height="600" frameborder="0"></iframe><a href="https://www.mapsdirections.info/en/measure-map-radius/">Radius distance map</a></div>
		
	</div>
	<div>
	
	<div>

	</div>
	</div>
	<!--Footer-->
	
    <div class="col-md-12 col-sm-12">
	<hr>
	<footer>
		<p style="text-align: center;"><a href="#header">Home</a></p>
		<p style="text-align: center;"><a href="#header">Birthday</a></p>
		<p style="text-align: center;"><a href="#header">Anniversary</a></p>
		<p style="text-align: center;"><a href="#header">Flowers</a></p>
		<p style="text-align: center;"><a href="#header">Plants</a></p>
		<p style="text-align: center;"><a href="#header">About Us</a></p>
		<p style="text-align: center;"><a href="#header">Contact Us</a></p>
		<div style="text-align: center; font-size: 1.5em;">
			<a href="#" class="fa fa-facebook"></a>
			<a href="#" class="fa fa-twitter"></a>
			<a href="#" class="fa fa-google"></a>
			<a href="#" class="fa fa-envelope"></a>
			<a href="#" class="fa fa-linkedin"></a>
		</div>
		<p style="text-align: center;">&copy; Copyright 2021 floralhouse.com</p>

	</footer>
	<!--End of Footer-->
</div>

</div>
	
</body>
</html>
